import java.util.Scanner;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Menu {
    public static void main(String[] args) {
        Scanner print = new Scanner(System.in);
        int escolha = 0;
        String nomeSet = "";
        int cpf= "";
        int telefone = "";
        int id = 0; 

        do {
            // MENU
            System.out.println("\n Escolha uma das opções: ");
            System.out.println("\n [1] Insert ");
            System.out.println("\n [2] Update ");
            System.out.println("\n [3] Updaye Preparedt ");
            System.out.println("\n [4] Delete ");
            System.out.println("\n [5] Select ");
            System.out.println("\n\n Escolha: ");
            escolha = print.nextInt();

            switch (escolha) {
            case 1:
                System.out.println("\n Insert");
                System.out.println("\n ID: ");
                try{
                id_cliente = print.nextInt();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try{
                System.out.println("\n Nome: ");
                nomeSet = print.next();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try{
                System.out.println("\n Cpf: ");
                cpf = print.next();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try{
                System.out.println("\n Telefone: ");
                telefone = print.next();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try{
                    final String url = "jdbc:mysql://localhost:3306/java_avaliativo?useTimezone=true&serverTimezone=UTC";
                    final String user = "root";
                    final String password = "";
                    
                    Connection con = DriverManager.getConnection(url, user, password);
                    Statement statement = con.createStatement();
                    
                    statement.execute("Insert into cliente (id_cliente, nome, cpf, telefone) VALUES ("+id+", '"+nomeSet+"', '"+cpf+"', '
                    "+telefone+"')");
                    System.out.println("\n Cliente Cadastrado! ");
                    con.close();
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }   
                break;
            case 2:
                System.out.println("\n Update");
                System.out.println("\n Id: ");
                try{
                id_cliente = print.nextInt();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try{
                System.out.println("\n Nome: ");
                nomeSet = print.next();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try{
                System.out.println("\n Cpf: ");
                cpf = print.next();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try{
                System.out.println("\n Telefone: ");
                telefone = print.next();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try{
                    final String url = "jdbc:mysql://localhost:3306/java_avaliativo?useTimezone=true&serverTimezone=UTC";
                    final String user = "root";
                    final String password = "";
                    
                    Connection con = DriverManager.getConnection(url, user, password);
                    Statement statement = con.createStatement();
                    statement.execute("UPDATE cliente SET nome = '"+nomeSet+"', cpf = '"+cpf+"', telefone = '"+telefone+"' WHERE id_cliente = "+id_cliente+"");
                    System.out.println("\n Cliente Editado! ");
                    con.close();
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }
                break;
            case 3:
                System.out.println("\n Update Prepared");
                System.out.println("\n Id: ");
                try{
                id_cliente = print.nextInt();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try{
                System.out.println("\n Nome: ");
                nomeSet = print.next();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try{
                System.out.println("\n Cpf: ");
                cpf = print.next();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try{
                System.out.println("\n Telefone: ");
                telefone = print.next();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try {
                    final String url = "jdbc:mysql://localhost:3306/java_avaliativo?useTimezone=true&serverTimezone=UTC";
                    final String user = "root";
                    final String password = "";

                    Connection con = DriverManager.getConnection(url, user, password);
                    PreparedStatement Statement = con.prepareStatement(
                        "UPDATE cliente SET nome = ?, cpf = ?, telefone = ? WHERE id_cliente = ?", PreparedStatement.RETURN_GENERATED_KEYS);
                    Statement.setString(1, nomeSet);
                    Statement.setInt(2, cpf);
                    Statement.setInt(3, telefone);
                    Statement.setInt(4, id);
                    
                    if(Statement.executeUpdate() > 0){
                        ResultSet resultado = Statement.getGeneratedKeys();
                        if(resultado.next()){
                            resultado.getString(1);
                            resultado.getInt(2);
                            resultado.getInt(3);
                            resultado.getInt(4);
                        }
                    }
                    System.out.println("\n Cliente atualizado! ");
                    con.close();
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
                break;
                    
            case 4:
                System.out.println("\n Delete");
                System.out.println("\n Id: ");
                try{
                id_cliente = print.nextInt();
                } catch(Exception e){
                    System.out.println(e.getMessage());
                }
                try{
                    final String url = "jdbc:mysql://localhost:3306/java_avaliativo?useTimezone=true&serverTimezone=UTC";
                    final String user = "root";
                    final String password = "";
                    
                    Connection con = DriverManager.getConnection(url, user, password);
                    Statement statement = con.createStatement();
                    

                    statement.execute("DELETE FROM cliente WHERE id_cliente = "+id);
                    System.out.println("\n Cliente Cadastrado ");
                    con.close();
                    System.out.println("\n Usuario deletado ");
                    } catch (SQLException e) {
                        System.out.println(e.getMessage());
                    }
                break;
            case 5:
                System.out.println("\n Select \n");
                try {
                    final String url = "jdbc:mysql://localhost:3306/java_avaliativo?useTimezone=true&serverTimezone=UTC";
                    final String user = "root";
                    final String password = "";

                    Connection con = DriverManager.getConnection(url, user, password);
                    Statement statement = con.createStatement();
                    ResultSet results = statement.executeQuery("SELECT * FROM cliente");
                    while (results.next()) {
                        Cliente cliente = new Cliente(
                            results.getInt("id_cliente"),
                            results.getString("nome"), 
                            results.getInt("cpf"), 
                            results.getInt("Telefone"));
                        System.out.println(cliente);
                    }
                    con.close();
                } catch (SQLException e) {
                    System.out.println(e.getMessage());
                }
                break;

            
            }

        } while (escolha < 1 && escolha > 8);
        print.close();
    }
}
