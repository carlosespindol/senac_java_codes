import java.sql.Date;
import java.util.Objects;

public class Chefe {
    
    private int id_chefe;
    private String nome;
    private int cpf;
    private int data_nasc;

    public Chefe(int id_chefe, String nome, int cpf, int data_nasc) {
        this.id_chefe = id_chefe;
        this.nome = nome;
        this.cpf = cpf;
        this.data_nasc = telefone;
    }

    public int getId_chefe() {
        return this.id_chefe;
    }

    public void setId_chefe(int id_chefe) {
        this.id_chefe = id_chefe;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return this.cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getData_nasc() {
        return this.data_nasc;
    }

    public void Data_nasc(Date data_nasc) {
        this.data_nasc = data_nasc;
    }


    public Chefe id_chefe(int id_chefe) {
        setId_chefe(id_chefe);
        return this;
    }

    public Chefe nome(String nome) {
        setNome(nome);
        return this;
    }

    public Chefe cpf(String cpf) {
        setCpf(cpf);
        return this;
    }

    public Chefe data_nasc(Date data_nasc) {
        setData_nasc(data_nasc);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Chefe)) {
            return false;
        }
        Chefe chefe = (Chefe) o;
        return id_chefe == chefe.id_chefe;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id_chefe, nome, cpf, data_nasc);
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId_chefe() + "'" +
            ", nome='" + getNome() + "'" +
            ", cpf='" + getCpf() + "'" +
            ", data_nasc='" + getData_nasc() + "'" +
            "}";
    }


}