import java.sql.Date;
import java.util.Objects;

public class Cliente {
    
    private int id_cliente;
    private String nome;
    private int cpf;
    private int telefone;

    public Cliente(int id_cliente, String nome, int cpf, int telefone) {
        this.id_cliente = idcliente;
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
    }

    public int getId_cliente() {
        return this.id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return this.cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getData_nasc() {
        return this.data_nasc;
    }

    public String getTelefone() {
        return this.Telefone;
    }

    public Cliente id_cliente(int id_cliente) {
        setId_cliente(id_cliente);
        return this;
    }

    public Cliente nome(String nome) {
        setNome(nome);
        return this;
    }

    public Cliente cpf(String cpf) {
        setCpf(cpf);
        return this;
    }

    public Cliente telefone(String telefone) {
        setTelefone(telefone);
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof Cliente)) {
            return false;
        }
        Cliente cliente = (Cliente) o;
        return id_cliente == cliente.id_cliente;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id_cliente, nome, cpf, telefone);
    }

    @Override
    public String toString() {
        return "{" +
            " id='" + getId_cliente() + "'" +
            ", nome='" + getNome() + "'" +
            ", cpf='" + getCpf() + "'" +
            ", telefone='" + getTelefone() + "'" +
            "}";
    }


}