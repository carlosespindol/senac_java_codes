import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Home {
    public static void main(String[] args) {
        try{
            final String url = "jdbc:mysql://localhost:3306/java_avaliativo?useTimezone=true&serverTimezone=UTC";
            final String user = "root";
            final String password = "";
            
            Connection con = DriverManager.getConnection(url, user, password);
            Statement statement = con.createStatement();
            ResultSet results = statement.executeQuery("SELECT * FROM cliente");
            while(results.next()){
                Cliente cliente = new Cliente(
                    results.getInt("id_cliente"),
                    results.getString("nome"),
                    results.getString("cpf"),
                    results.getDate("telefone")
                );
                System.out.println(cliente);
            }
            con.close();

            Connection con2 = DriverManager.getConnection(url, user, password);
            PreparedStatement prepStatement = con2.prepareStatement(
                "DELETE FROM cliente WHERE id_cliente = ?",
                PreparedStatement.RETURN_GENERATED_KEYS
            );
            prepStatement.setInt(1, 1);

            if(prepStatement.executeUpdate() > 0){
                ResultSet resultado = statement.getGeneratedKeys();

                if(resultado.next()){
                    resultado.getInt(1);
                }
            }

            con2.close();

        } catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
}