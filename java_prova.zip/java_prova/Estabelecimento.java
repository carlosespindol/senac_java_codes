import java.util.ArrayList;

public class Estabelecimento {
    int id;
    ArrayList<Cliente> clientes = new ArrayList<>();
    ArrayList<Mercado> mercados = new ArrayList<>();
    ArrayList<Receita> receitas = new ArrayList<>();
    ArrayList<Padaria> padarias = new ArrayList<>();

    public Estabelecimento(int id)

    {
        this.id = id;
        
    }
    
    public void adicionarMercado(Mercado mercado){
            this.mercados.add(mercado);
    }

    public void adicionarCliente(Cliente cliente) {
        this.clientes.add(cliente);
    }

    public void adicionarPadaria(Padaria padaria) {
        this.padarias.add(padaria);

    }


public static void main(String[] args) {
        Mercado mercado01 = new Mercado(1, "Seu vizinho", "02/01/2003", "Bananas", 1, 16370970, "Rua Palmares, 4598", 80, "Itaum",
                "Joinville");
        Mercado mercado02 = new Mercado(2, "Compre Mais", "21/01/2010", "Molhos", 2, 26268094, "Rua dos lombres, 1245", 901,
                "Aventureiro", "Joinville");
        Mercado mercado03 = new Mercado(3, "Atacadão", "30/01/2009", "Carnes", 3, 39873743, "Rua Maria Vichi, 456", 826,
                "America", "Joinville");
        
        Padaria padaria01 = new Padaria(1, "Com amor", "02/01/2003", 1, 16370970, "Rua Palmares, 34", 80, "Itaum",
                "Joinville");
        Padaria padaria02 = new Padaria(2, "Com saudade", "21/01/2010", 2, 26268094, "Rua dos lombres, 1402", 901,
                "Aventureiro", "Joinville");
        Padaria padaria03 = new Padaria(3, "Com carinho", "30/01/2009", 3, 39873743, "Rua Maria Vichi, 821", 826,
                 "America", "Joinville");
        Cliente cliente01 = new Cliente(1, "Mario", 458785,34295459);
        Cliente cliente02 = new Cliente(1, "Roberto", 158755,34295469);
        Cliente cliente03 = new Cliente(1, "Claudia", 455789,34295478);


        /* Padarias */

        System.out.println("\n Mercado");
        System.out.println(" Mercado 1 - " + mercado01.nome);
        System.out.println("  Rua: " + mercado01.endereco.rua + ", Numero: " + mercado01.endereco.numero + ", Promoção: " + mercado01.promocao +
        ", Bairro: " + mercado01.endereco.bairro + ", Cidade: " + mercado01.endereco.cidade + ", CEP: " + mercado01.endereco.cep + "\n");

        System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
        System.out.println(" Mercado 2 - " + mercado02.nome);
        System.out.println("  Rua: " + mercado02.endereco.rua + ", Numero: " + mercado02.endereco.numero + ", Promoção: " + mercado02.promocao +
        ", Bairro: " + mercado02.endereco.bairro + ", Cidade: " + mercado02.endereco.cidade + ", CEP: " + mercado02.endereco.cep + "\n");

        System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
        System.out.println(" Mercado 3 - " + mercado03.nome);
        System.out.println("  Rua: " + mercado03.endereco.rua + ", Numero: " + mercado03.endereco.numero + ", Promoção: " + mercado03.promocao +
        ", Bairro: " + mercado03.endereco.bairro + ", Cidade: " + mercado03.endereco.cidade + ", CEP: " + mercado03.endereco.cep + "\n");

        /* Padarias */


        System.out.println("\n Padaria");
        System.out.println(" Padaria 1 - " + padaria01.nome);
        System.out.println("  Rua: " + padaria01.endereco.rua + ", Numero: " + padaria01.endereco.numero + ", Bairro: "
                + padaria01.endereco.bairro + ", Cidade: " + padaria01.endereco.cidade + ", CEP: "
                + padaria01.endereco.cep + "\n");
        System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
        System.out.println(" Padaria 2 - " + padaria02.nome);
        System.out.println("  Rua: " + padaria02.endereco.rua + ", Numero: " + padaria02.endereco.numero + ", Bairro: "
                + padaria02.endereco.bairro + ", Cidade: " + padaria02.endereco.cidade + ", CEP: "
                + padaria02.endereco.cep + "\n");
        System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
        System.out.println(" Padaria 3 - " + padaria03.nome);
        System.out.println("  Rua: " + padaria03.endereco.rua + ", Numero: " + padaria03.endereco.numero + ", Bairro: "
                + padaria03.endereco.bairro + ", Cidade: " + padaria03.endereco.cidade + ", CEP: "
                + padaria03.endereco.cep + "\n");

        /* Cliente */

        System.out.println("\n Cliente");
        System.out.println(
                " Nome: " + cliente01.nome + ", CPF: " + cliente01.cpf + ", Telefone: " + cliente01.telefone + "\n");
        System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
        System.out.println(
                " Nome: " + cliente02.nome + ", CPF: " + cliente02.cpf + ", Telefone: " + cliente02.telefone + "\n");
        System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
        System.out.println(
                " Nome: " + cliente03.nome + ", CPF: " + cliente03.cpf + ", Telefone: " + cliente03.telefone + "\n");

        /* Chefs */

        System.out.println("\n Chefs");
        Chef chef01 = new Chef(2, "Joe Duplantier", 128755, "20/01/1973");
        Chef chef02 = new Chef(5, "Mario Duplantier", 839990, "24/09/1978");
        Chef chef03 = new Chef(7, "Jean Mich", 140201, "09/12/1969");

        System.out.println(
                " Nome: " + chef01.nome + ", CPF: " + chef01.cpf + ", Data de Nascimento: " + chef01.dataNasc + "\n");
        System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
        System.out.println(
                " Nome: " + chef02.nome + ", CPF: " + chef02.cpf + ", Data de Nascimento: " + chef02.dataNasc + "\n");
        System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
        System.out.println(
                " Nome: " + chef03.nome + ", CPF: " + chef03.cpf + ", Data de Nascimento: " + chef03.dataNasc + "\n");

        /* Receita */

        /* 1 */
        Receita receita01 = new Receita(1, "Cozido", "cozir", 4, chef01);
        Receita receita02 = new Receita(2, "Cuzcuz Paulista", "Fazer massa", 2, chef01);
        Receita receita03 = new Receita(3, "Docinho", "colocar granulado", 6, chef01);
        Receita receita04 = new Receita(4, "Sonho", "rechear", 3, chef01);
        Receita receita05 = new Receita(5, "Salgado", "preparar Massa", 5, chef01);
        padaria01.adicionarReceita(receita01);
        padaria01.adicionarReceita(receita02);
        padaria01.adicionarReceita(receita03);
        padaria01.adicionarReceita(receita04);
        padaria01.adicionarReceita(receita05);

        /* 2 */

        Receita receita06 = new Receita(6, "Pastel de Carne", "assar", 6, chef02);
        Receita receita07 = new Receita(7, "Rosbife", "fritar", 5, chef02);
        Receita receita08 = new Receita(8, "Picolé", "congelar", 7, chef02);
        Receita receita09 = new Receita(9, "Maria Mole", "esticar", 1, chef02);
        Receita receita10 = new Receita(10, "Sopa de Tomate", "Gelar", 3, chef02);
        padaria02.adicionarReceita(receita06);
        padaria02.adicionarReceita(receita07);
        padaria02.adicionarReceita(receita08);
        padaria02.adicionarReceita(receita09);
        padaria02.adicionarReceita(receita10);

        /* 3 */

        Receita receita11 = new Receita(11, "Brownie", "Congelar", 7, chef03);
        Receita receita12 = new Receita(12, "Peru", "rechear", 3, chef03);
        Receita receita13 = new Receita(13, "Lasanha", "assar", 4, chef03);
        Receita receita14 = new Receita(14, "Maionese", "colocar ingredientes", 1, chef03);
        Receita receita15 = new Receita(15, "Batata Frita", "fritar", 7, chef03);
        padaria03.adicionarReceita(receita11);
        padaria03.adicionarReceita(receita12);
        padaria03.adicionarReceita(receita13);
        padaria03.adicionarReceita(receita14);
        padaria03.adicionarReceita(receita15);

        /* 4 */
        Receita receita16 = new Receita(16, "Cozido", "cozir", 4, chef01);
        Receita receita17 = new Receita(17, "Cuzcuz Paulista", "Fazer massa", 2, chef01);
        Receita receita18 = new Receita(18, "Docinho", "colocar granulado", 6, chef01);
        Receita receita19 = new Receita(19, "Sonho", "rechear", 3, chef01);
        Receita receita20 = new Receita(20, "Salgado", "preparar Massa", 5, chef01);
        chef01.adicionarReceita(receita16);
        chef01.adicionarReceita(receita17);
        chef01.adicionarReceita(receita18);
        chef01.adicionarReceita(receita19);
        chef01.adicionarReceita(receita20);

        /* 5 */

        Receita receita21 = new Receita(21, "Pastel de Carne", "assar", 6, chef02);
        Receita receita22 = new Receita(22, "Rosbife", "fritar", 5, chef02);
        Receita receita23 = new Receita(23, "Picolé", "congelar", 7, chef02);
        Receita receita24 = new Receita(24, "Maria Mole", "esticar", 1, chef02);
        Receita receita25 = new Receita(25, "Sopa de Tomate", "Gelar", 3, chef02);
        chef02.adicionarReceita(receita21);
        chef02.adicionarReceita(receita22);
        chef02.adicionarReceita(receita23);
        chef02.adicionarReceita(receita24);
        chef02.adicionarReceita(receita25);

        /* 6 */

        Receita receita26 = new Receita(26, "Brownie", "Congelar", 7, chef03);
        Receita receita27 = new Receita(27, "Peru", "rechear", 3, chef03);
        Receita receita28 = new Receita(28, "Lasanha", "assar", 4, chef03);
        Receita receita29 = new Receita(29, "Maionese", "colocar ingredientes", 1, chef03);
        Receita receita30 = new Receita(30, "Batata Frita", "fritar", 7, chef03);
        chef03.adicionarReceita(receita26);
        chef03.adicionarReceita(receita27);
        chef03.adicionarReceita(receita28);
        chef03.adicionarReceita(receita29);
        chef03.adicionarReceita(receita30);

        /* 7 */
        Receita receita31 = new Receita(31, "Cozido", "cozir", 4, chef01);
        Receita receita32 = new Receita(32, "Cuzcuz Paulista", "Fazer massa", 2, chef01);
        Receita receita33 = new Receita(33, "Docinho", "colocar granulado", 6, chef01);
        Receita receita34 = new Receita(34, "Sonho", "rechear", 3, chef01);
        Receita receita35 = new Receita(35, "Salgado", "preparar Massa", 5, chef01);
        cliente01.adicionarReceita(receita31);
        cliente01.adicionarReceita(receita32);
        cliente01.adicionarReceita(receita33);
        cliente01.adicionarReceita(receita34);
        cliente01.adicionarReceita(receita35);

        /* 8 */
        Receita receita36 = new Receita(36, "Pastel de Carne", "assar", 6, chef02);
        Receita receita37 = new Receita(37, "Rosbife", "fritar", 5, chef02);
        Receita receita38 = new Receita(38, "Picolé", "congelar", 7, chef02);
        Receita receita39 = new Receita(39, "Maria Mole", "esticar", 1, chef02);
        Receita receita40 = new Receita(40, "Sopa de Tomate", "Gelar", 3, chef02);
        cliente02.adicionarReceita(receita36);
        cliente02.adicionarReceita(receita37);
        cliente02.adicionarReceita(receita38);
        cliente02.adicionarReceita(receita39);
        cliente02.adicionarReceita(receita40);

        /* 9 */
        Receita receita41 = new Receita(41, "Brownie", "Congelar", 7, chef03);
        Receita receita42 = new Receita(42, "Peru", "rechear", 3, chef03);
        Receita receita43 = new Receita(43, "Lasanha", "assar", 4, chef03);
        Receita receita44 = new Receita(44, "Maionese", "colocar ingredientes", 1, chef03);
        Receita receita45 = new Receita(45, "Batata Frita", "fritar", 7, chef03);
        cliente03.adicionarReceita(receita41);
        cliente03.adicionarReceita(receita42);
        cliente03.adicionarReceita(receita43);
        cliente03.adicionarReceita(receita44);
        cliente03.adicionarReceita(receita45);

        System.out.println("Receita para cliente 1");
        for (Receita Receita : cliente01.receitas) {
            System.out.println("Nome da Receita: " + Receita.nome + ", Etapa da Receita: " + Receita.etapa
                    + ", Numero da Etapa: " + Receita.numEtapa);
        }

        System.out.println("Receita para cliente 2");
        for (Receita Receita : cliente02.receitas) {
            System.out.println("Nome da Receita: " + Receita.nome + ", Etapa da Receita: " + Receita.etapa
                    + ", Numero da Etapa: " + Receita.numEtapa);
        }

        System.out.println("Receita para cliente 3");
        for (Receita Receita : cliente03.receitas) {
            System.out.println("Nome da Receita: " + Receita.nome + ", Etapa da Receita: " + Receita.etapa
                    + ", Numero da Etapa: " + Receita.numEtapa);
        }
        System.out.println("\n\n");

        System.out.println("Receita para chef 1");
        for (Receita Receita : chef01.receitas) {
            System.out.println("Nome da Receita: " + Receita.nome + ", Etapa da Receita: " + Receita.etapa
                    + ", Numero da Etapa: " + Receita.numEtapa);
        }

        System.out.println("Receita para chef 2");
        for (Receita Receita : chef02.receitas) {
            System.out.println("Nome da Receita: " + Receita.nome + ", Etapa da Receita: " + Receita.etapa
                    + ", Numero da Etapa: " + Receita.numEtapa);
        }

        System.out.println("Receita para chef 3");
        for (Receita Receita : chef03.receitas) {
            System.out.println("Nome da Receita: " + Receita.nome + ", Etapa da Receita: " + Receita.etapa
                    + ", Numero da Etapa: " + Receita.numEtapa);
        }
        System.out.println("\n\n");
        System.out.println("\n Receita para padaria 1");
        for (Receita Receita : padaria01.receitas) {
            System.out.println("Nome da Receita: " + Receita.nome);
        }
        System.out.println("\n Receita para padaria 2");
        for (Receita Receita : padaria02.receitas) {
            System.out.println("Nome da Receita: " + Receita.nome);
        }
        System.out.println("\n Receita para padaria 3");
        for (Receita Receita : padaria03.receitas) {
            System.out.println("Nome da Receita: " + Receita.nome);
        }
        System.out.println("\n\n");

        
    }

}