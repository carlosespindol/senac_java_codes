public class Endereco {
    int id;
    int cep;
    String rua;
    int numero;
    String bairro;
    String cidade;
    Padaria padaria;
    Mercado mercado;
    

    public Endereco(
    int id,
    int cep,
    String rua, 
    int numero, 
    String bairro,  
    String cidade,
    Padaria padaria,
    Mercado mercado
    )

    {
        this.id = id;
        this.cep = cep;
        this.rua = rua;
        this.numero = numero;
        this.bairro = bairro;
        this.cidade = cidade;
        this.padaria = padaria;
        this.mercado = mercado;
        
    }
    
}