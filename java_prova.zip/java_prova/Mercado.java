public class Mercado {
    int id;
    String nome;
    String datadeabert;
    String promocao;
    Endereco endereco;

    
    public Mercado(int id, String nome, String datadeabert, String promocao, int Id, int cep, String rua, int numero, String bairro,
            String cidade)

    {
        this.id = id;
        this.nome = nome;
        this.datadeabert = datadeabert;
        this.promocao = promocao;
        this.endereco = new Endereco(Id, cep, rua, numero, bairro, cidade, null, this);
    }
}