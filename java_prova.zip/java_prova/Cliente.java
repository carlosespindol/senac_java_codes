import java.util.ArrayList;
public class Cliente {
    int id;
    String nome;
    int cpf;
    int telefone;
    ArrayList<Receita> receitas = new ArrayList<>();

    public Cliente(int id, String nome, int cpf, int telefone)

    {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
    }

    public void adicionarReceita(Receita Receita) {
        this.receitas.add(Receita);
    }
}