import java.util.ArrayList;
public class Padaria {
    int id;
    String nome;
    String datadeabert;
    Endereco endereco;
    ArrayList<Receita> receitas = new ArrayList<>();

    public Padaria(int id, String nome, String datadeabert, int Id, int cep, String rua, int numero, String bairro,
            String cidade)

    {
        this.id = id;
        this.nome = nome;
        this.datadeabert = datadeabert;
        this.endereco = new Endereco(Id, cep, rua, numero, bairro, cidade, this, null);
    }

    public void adicionarReceita(Receita receita) {
        this.receitas.add(receita);
    }
}